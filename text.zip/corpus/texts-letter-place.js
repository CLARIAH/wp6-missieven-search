corpusData["texts"]["letter"]["place"] = `aan boord van het Wapen van Amsterdam voor Ile de Mayo

aan boord van het Wapen van Amsterdam liggende in de Tafelbaai

aan boord van het Wapen van Amsterdam ter Rede van Mauritius

Kasteel Nassau op Banda-Neira

aan boord van de Vere voor Maleyo

Fort Mauritius nabij Ngofakiaha op het eiland Makéan

Fort Mauritius nabij Ngofakiaha op het eiland Makéan

Fort Mauritius nabij Ngofakiaha op het eiland Makéan

Fort Mauritius nabij Ngofakiaha op het eiland Makéan

-1

Fort Mauritius nabij Ngofakiaha op het eiland Makéan

Fort Mauritius nabij Ngofakiaha op het eiland Makéan

Fort Mauritius nabij Ngofakiaha op het eiland Makéan

-1

Bantam

Bantam

Bantam

Bantam

Bantam

Bantam

Bantam

Bantam

Bantam

Bantam

Bantam

Ternate

Ternate

Banda-Neira

Amboina

Bantam

Bantam

Bantam

Jakatra

Kasteel Nassau op Banda-Neira

Wapen van Amsterdam voor Banda-Neira

Kasteel Mauritius nabij Ngofakiaha op Makéan

Kasteel Jakatra

Kasteel Jakatra

Kasteel Jakatra

Kasteel Jakatra

Kasteel Jakatra

Kasteel Jakatra

Kasteel Jakatra

Kasteel Jakatra

Kasteel Jakatra

Kasteel Jakatra

Kasteel Jakatra

Schip Nieuw Hollandia ter Rede van Banda-Neira 

Kasteel Jakatra

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

in het Schip Deventer nabij de zuidpunt van Afrika

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

aan boord van de Wesel in Straat Sunda

Batavia

Batavia

Batavia

Batavia

aan boord van de Utrecht nabij de Vlakke Hoek

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia


Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia


Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia


Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia


Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia


Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia


Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia


Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia


Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia


Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia


Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia


Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia


Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia


Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia

Batavia


`